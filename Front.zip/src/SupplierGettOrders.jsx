import React from 'react'

function SupplierGettOrders({userId}) {
  return (
    <>
     
    </>
  )
}

export default SupplierGettOrders