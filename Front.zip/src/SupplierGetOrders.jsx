import React from 'react'

function SupplierGetOrders() {
  return (
    <div>SupplierGetOrders</div>
  )
}

export default SupplierGetOrders