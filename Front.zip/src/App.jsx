import { useState } from "react";
import "./App.css";
import PageRoute from "./Context/PageRoute";


function App() {
  return (
    <>
    
      <PageRoute />
    </>
  );
}

export default App;
