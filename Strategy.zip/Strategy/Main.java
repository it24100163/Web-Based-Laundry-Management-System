
public class Main {
    public static void main(String[] args) {

        PaymentContext context = new PaymentContext();
        CardPayment cardPayment = new CardPayment("456789", 102L);
        context.setPaymentStrategy(cardPayment);
        context.executePayment("CARD", 22.9);
        System.out.println("Card payment successful.");

        System.out.println("\n.................................... \n");

        CashOnDeliveryPayment cachePayment = new CashOnDeliveryPayment(120L);
        context.setPaymentStrategy(cachePayment);
        context.executePayment("CashOnDeliveryPayment", 22.9);
        System.out.println("CashOnDeliveryPayment successful.");

        System.out.println("\n.................................... \n");

        MobileWalletPayment mobilepayment = new MobileWalletPayment(102L,"102LkPho9");
        context.setPaymentStrategy(mobilepayment);
        context.executePayment("MobileWalletPayment", 22.9);
        System.out.println("MobileWalletPayment successful.");

        System.out.println("\n.................................... \n");

    }
}
