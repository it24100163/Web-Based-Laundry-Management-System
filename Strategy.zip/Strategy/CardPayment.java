public class CardPayment implements Strategy {

    private String cardNumber;
    private Long customerId;

    public CardPayment(String cardNumber, Long customerId) {
        this.cardNumber = cardNumber;
        this.customerId = customerId;
        System.out.println("Card Payment Initialized for Customer ID: " + customerId);
    }

    @Override
    public boolean doPayment(String paymentMethod, double amount) {
        System.out.println("Processing card payment...");
        if (amount > 0 && paymentMethod.equalsIgnoreCase("CARD")) {
            System.out.println("Paid $" + amount + " using Card ending with ****"
                    + cardNumber.substring(Math.max(0, cardNumber.length() - 4)));
            return true;
        }
        System.out.println("Card payment failed.");
        return false;
    }
}
