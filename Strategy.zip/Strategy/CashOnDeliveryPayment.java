
public class CashOnDeliveryPayment implements Strategy {

    Long CustomerID;

    public CashOnDeliveryPayment(Long CustomerID) {
        this.CustomerID = CustomerID;
        System.out.println("Payment  Done by Customer : " + this.CustomerID);
    }

    @Override
    public boolean doPayment(String paymentMethod, double amount) {
        System.out.println("Processing cash on delivery...");
        if (amount > 0 && paymentMethod.equalsIgnoreCase("CASH_ON_DELIVERY")) {
            System.out.println("Payment of $" + amount + " will be collected upon delivery.");
            return true;
        }
        System.out.println("Cash on delivery setup failed.");
        return false;
    }
}
