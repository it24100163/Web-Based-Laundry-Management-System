
public class PaymentContext {
    private Strategy strategy;


    public void setPaymentStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    public void executePayment(String paymentMethod, double amount) {
        if (strategy == null) {
            System.out.println("Payment strategy not set!");
            return;
        }
        boolean success = strategy.doPayment(paymentMethod, amount);
        if (success) {
            System.out.println("Payment successful!\n");
        } else {
            System.out.println("Payment failed.\n");
        }
    }
}
