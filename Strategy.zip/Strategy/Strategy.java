// Strategy.java
public interface Strategy {
    boolean doPayment(String paymentMethod, double amount);
}
