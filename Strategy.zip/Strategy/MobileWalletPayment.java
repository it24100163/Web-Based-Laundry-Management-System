
public class MobileWalletPayment implements Strategy {

    Long CustomerID;
    String MobileWallID;

    public MobileWalletPayment(Long CustomerID, String MobileWallID) {
        this.CustomerID = CustomerID;
        this.MobileWallID = MobileWallID;
        System.out.println("Payment Done by Customer using this Mobile Wallet : " + this.CustomerID + this.MobileWallID);
    }

    @Override
    public boolean doPayment(String paymentMethod, double amount) {
        System.out.println("Processing mobile wallet payment...");
        if (amount > 0 && paymentMethod.equalsIgnoreCase("MOBILE_WALLET")) {
            System.out.println("Paid $" + amount + " using Mobile Wallet.");
            return true;
        }
        System.out.println("Mobile wallet payment failed.");
        return false;
    }
}
