package com.example.Londery_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LonderyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
